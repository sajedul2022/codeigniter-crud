<div class="container">
    <h1>About US</h1>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Officia similique dolores laboriosam perspiciatis deserunt delectus temporibus dolorem blanditiis tenetur. Maxime tempora reiciendis voluptatibus ea repudiandae excepturi ad nisi modi distinctio autem. Odio at praesentium illo harum aut perspiciatis perferendis nobis accusamus modi eveniet, cumque, dolorem inventore quos exercitationem veniam ea!</p>
</div>